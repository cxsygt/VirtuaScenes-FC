# 编辑阵容功能实现计划

## Context
用户希望在"我的球队"中增加"编辑阵容"选项,可自定义球队初始阵型(所有球员排在己方半场,每名球员可自定义站位),进入比赛后主队按此阵型排列。

当前阵型在 `game.js` 的 `Team.setupFormation` 里硬编码(主队 id===0 / 客队 id===1 对称),无自定义机制。需要:新增编辑器 UI、阵型持久化、比赛引擎读取自定义阵型。

## 方案

### 1. storage.js — 阵型持久化
- `keys` 加 `FORMATION: 'football_formation'`。
- `getFormation()`:读取,返回 `{ [playerId]: {x, y} }` 或 `{}`(无则空对象)。
- `saveFormation(form)`:`JSON.stringify` 保存。
- `clearFormation()`:`removeItem`(重置用)。
- `resetAll()`:加 `localStorage.removeItem(this.keys.FORMATION)`。

### 2. game.js — setupFormation 主队读自定义
修改 `Team.setupFormation`([game.js:166-190](file:///c:\Users\HUAWEI\Desktop\VirtuaScenes%20FC%201.1\game.js#L166)):
- 保持现有默认坐标分配逻辑(主客队)。
- 默认分配后,**仅主队(id===0)** 读 `Storage.getFormation()`,对 `playerId` 匹配的球员覆盖 `p.x`/`p.y`。
- 客队不变(继续用默认阵型)。
- 效果:无自定义 → 用默认;有自定义 → 主队按自定义排列。

### 3. menu.js — 编辑阵容界面与交互
- **入口**:`getTeamHTML`([menu.js:342-345](file:///c:\Users\HUAWEI\Desktop\VirtuaScenes%20FC%201.1\menu.js#L342))的 `.team-tabs` 后加"编辑阵容"按钮。球队为空时点击提示先招募球员。
- **`showFormationEditor()`**:渲染编辑器界面到 `menuScreen`。
- **界面布局**(左列表 + 右 canvas + 底部按钮):
  - 左侧:球队 11 人小卡片列表,点击选中(高亮)。
  - 右侧:canvas 全场 50×30,己方半场(x<25)高亮可放置,对方半场(x≥25)灰色。
  - 底部:保存 / 重置为默认 / 返回。
- **编辑器状态**:`Menu.formationEditor = { selectedId, positions:{playerId:{x,y}}, canvas, ctx, cellSize }`。
- **初始坐标**:已保存自定义 → 用之;否则用"半场默认"(全 x<25):GK[2,15]、DEF x=6(y=5/12/18/25)、MID x=12(y=8/15/22)、FWD x=20(y=8/15/22)。
- **`renderFormation()`**:canvas 绘制全场格子、己方半场高亮、球门标记、球员圆点(按 positions,显示号码/位置)、选中球员高亮边框。
- **`onFormationCanvasClick(e)`**:`screenToGrid` 转坐标后:
  - 点己方半场空格 + 有选中球员 → 移动该球员到此格。
  - 点己方半场已有球员 → 切换选中到该球员。
  - 点对方半场 → `showToast('只能放置在己方半场')`。
- **`selectFormationPlayer(id)`**:设 `selectedId` 并重渲染。
- **`saveFormation()`**:`Storage.saveFormation(positions)`,toast 成功,返回球队管理。
- **`resetFormation()`**:`Storage.clearFormation()`,positions 恢复半场默认,重渲染。
- canvas 坐标换算(`screenToGrid`/`gridToScreen`/`cellSize` 自适应)参考 ui.js([ui.js:40-54](file:///c:\Users\HUAWEI\Desktop\VirtuaScenes%20FC%201.1\ui.js#L40)),独立实现,因 ui.js 的 renderField 依赖比赛引擎状态。

### 4. style.css — 编辑器样式
- `.formation-editor`(flex:左列表 + 右 canvas)。
- `.formation-list`(左侧滚动列表,固定宽度)。
- `.formation-canvas-wrap`(右侧 canvas 居中)。
- `.formation-player-item`(小卡片,选中高亮)。
- `.formation-actions`(底部按钮组)。
- 复用现有 `.btn` / `.screen-header` 样式。

## 关键文件
| 文件 | 改动 |
|------|------|
| storage.js | 加 `FORMATION` 键 + `get/save/clearFormation`,`resetAll` 增删 |
| game.js | `setupFormation` 主队读自定义阵型覆盖默认坐标 |
| menu.js | `getTeamHTML` 加入口;新增 `showFormationEditor` 及渲染/交互/保存方法 |
| style.css | 加编辑器布局与卡片样式 |

## 交互方式说明
采用**点击放置**(选球员 → 点格子),非拖拽:实现简单可靠,canvas 坐标精度问题小,符合现有比赛界面的点击交互习惯。

## 验证
1. **node 逻辑验证**:stub `Storage.getFormation` 返回自定义坐标,加载 game.js,`Game.init()` 后检查主队球员坐标 = 自定义坐标;无自定义时 = 默认坐标;客队始终默认。
2. **浏览器验证**:球队管理 → 编辑阵容 → 选球员 → 点己方半场格子放置 → 点对方半场提示 → 保存 → 开始比赛 → 确认主队阵型 = 自定义;重置后恢复默认。
3. **半场约束**:所有放置仅限 x<25;保存的阵型全在己方半场。
