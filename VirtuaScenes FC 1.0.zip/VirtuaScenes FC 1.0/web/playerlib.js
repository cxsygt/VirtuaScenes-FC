// ========================================
// 球员库 - 星级分类、属性生成、等级升级
// ========================================

const StarConfig = {
    1: { totalPoints: 20, cost: 500 },
    2: { totalPoints: 25, cost: 1500 },
    3: { totalPoints: 30, cost: 4000 },
    4: { totalPoints: 35, cost: 10000 },
    5: { totalPoints: 40, cost: 25000 }
};

const ScoutConfig = {
    goldCost: 100,
    fundsCost: 10000,
    rates: { 1: 60, 2: 30, 3: 6, 4: 3, 5: 1 }
};

const MAX_LEVEL = 20;

// 属性池（按位置分）
const AttrPool = {
    GK: ['save', 'speed', 'dribble', 'tackle', 'pass', 'physique'],
    DEF: ['shoot', 'speed', 'dribble', 'tackle', 'pass', 'physique'],
    MID: ['shoot', 'speed', 'dribble', 'tackle', 'pass', 'physique'],
    FWD: ['shoot', 'speed', 'dribble', 'tackle', 'pass', 'physique']
};

const AttrNames = {
    shoot: '射门',
    save: '扑救',
    speed: '速度',
    dribble: '控球',
    tackle: '抢断',
    pass: '传球',
    physique: '身体'
};

const AttrWeights = {
    // 各位置属性权重（影响初始分配倾向）
    GK: { save: 3, speed: 1, dribble: 1, tackle: 2, pass: 1, physique: 2 },
    DEF: { shoot: 1, speed: 2, dribble: 2, tackle: 3, pass: 2, physique: 3 },
    MID: { shoot: 2, speed: 3, dribble: 3, tackle: 2, pass: 3, physique: 2 },
    FWD: { shoot: 3, speed: 3, dribble: 3, tackle: 1, pass: 2, physique: 2 }
};

const PlayerLib = {
    nextId: 1,

    // ===== 创建新球员 =====
    createPlayer(name, position, star) {
        const config = StarConfig[star];
        if (!config) return null;

        const id = 'p_' + Date.now() + '_' + (this.nextId++);
        const attrs = this.distributeAttributes(position, config.totalPoints);

        const player = {
            id: id,
            name: name,
            position: position,
            star: star,
            level: 0,
            exp: 0,
            createdAt: Date.now(),
            ...attrs
        };

        Storage.addPlayer(player);
        return player;
    },

    // 按权重分配属性点
    distributeAttributes(position, totalPoints) {
        const pool = AttrPool[position];
        const weights = AttrWeights[position];
        const attrs = {};

        // 初始分配：按权重比例分配60%的点数
        let remaining = Math.floor(totalPoints * 0.6);
        const weightSum = pool.reduce((s, a) => s + weights[a], 0);

        for (const attr of pool) {
            const share = Math.floor((weights[attr] / weightSum) * remaining);
            attrs[attr] = Math.max(1, Math.min(10, 3 + share));
        }

        // 剩余点数随机分配
        remaining = totalPoints - pool.reduce((s, a) => s + attrs[a], 0);
        for (let i = 0; i < remaining; i++) {
            const attr = pool[Math.floor(Math.random() * pool.length)];
            if (attrs[attr] < 10) attrs[attr]++;
        }

        // 确保每项至少1，且不超过10
        for (const attr of pool) {
            attrs[attr] = Math.max(1, Math.min(10, attrs[attr] || 1));
        }

        // 门将没有射门，其他没有扑救
        if (position === 'GK') {
            attrs.shoot = 0;
        } else {
            attrs.save = 0;
        }

        return attrs;
    },

    // ===== 升级相关 =====
    getUpgradeCost(currentLevel) {
        // n-1级升到n级需要 3n 导师卡
        if (currentLevel >= MAX_LEVEL) return null;
        return 3 * (currentLevel + 1);
    },

    canUpgrade(player) {
        if (player.level >= MAX_LEVEL) return { can: false, reason: '已达最高等级' };
        const cost = this.getUpgradeCost(player.level);
        const res = Storage.getResources();
        if (res.mentorCards < cost) return { can: false, reason: '导师卡不足(需' + cost + '张)' };
        return { can: true, cost: cost };
    },

    // 执行升级
    upgradePlayer(playerId, chosenAttr = null) {
        const players = Storage.getPlayers();
        const player = players.find(p => p.id === playerId);
        if (!player) return { success: false, message: '球员不存在' };

        const check = this.canUpgrade(player);
        if (!check.can) return { success: false, message: check.reason };

        // 扣除导师卡
        const res = Storage.getResources();
        res.mentorCards -= check.cost;
        Storage.saveResources(res);

        // 升级
        player.level++;

        // 5级、10级：随机增加一个属性
        // 15级、20级：指定增加一个属性
        const milestone = player.level;
        const pool = AttrPool[player.position];
        let increasedAttr = null;

        if (milestone === 5 || milestone === 10) {
            // 随机选一个未满的属性
            const available = pool.filter(a => player[a] < 10);
            if (available.length > 0) {
                increasedAttr = available[Math.floor(Math.random() * available.length)];
                player[increasedAttr]++;
            }
        } else if (milestone === 15 || milestone === 20) {
            // 指定增加
            if (chosenAttr && pool.includes(chosenAttr) && player[chosenAttr] < 10) {
                increasedAttr = chosenAttr;
                player[chosenAttr]++;
            } else {
                // 如果没指定或已满，随机选一个
                const available = pool.filter(a => player[a] < 10);
                if (available.length > 0) {
                    increasedAttr = available[Math.floor(Math.random() * available.length)];
                    player[increasedAttr]++;
                }
            }
        }

        Storage.savePlayers(players);

        let msg = player.name + ' 升至 ' + player.level + ' 级！';
        if (increasedAttr) {
            msg += ' ' + AttrNames[increasedAttr] + '+1';
            if (milestone === 5 || milestone === 10) msg += '（随机奖励）';
            if (milestone === 15 || milestone === 20) msg += '（指定奖励）';
        }

        return { success: true, message: msg, player: player };
    },

    // ===== 查询辅助 =====
    getPlayerTotalAttrs(player) {
        const pool = AttrPool[player.position];
        return pool.reduce((s, a) => s + (player[a] || 0), 0);
    },

    getPotentialMaxAttrs(star, level) {
        // 星级基础 + 升级加成
        const config = StarConfig[star];
        let total = config.totalPoints;
        // 每级平均增加 ~1 点
        total += level;
        return total;
    },

    getUpgradeMilestoneHint(level) {
        if (level === 4) return '下次升级(5级): 随机+1属性';
        if (level === 9) return '下次升级(10级): 随机+1属性';
        if (level === 14) return '下次升级(15级): 可指定+1属性';
        if (level === 19) return '下次升级(20级): 可指定+1属性';
        return null;
    },

    // ===== 预设球员（可招募）=====
    generatePresetPlayers() {
        const presets = [
            // 1星球员
            { name: '新手门将', pos: 'GK', star: 1 },
            { name: '业余后卫', pos: 'DEF', star: 1 },
            { name: '街头中场', pos: 'MID', star: 1 },
            { name: '青训前锋', pos: 'FWD', star: 1 },
            // 2星球员
            { name: '稳健门将', pos: 'GK', star: 2 },
            { name: '防守后卫', pos: 'DEF', star: 2 },
            { name: '组织中场', pos: 'MID', star: 2 },
            { name: '边路快马', pos: 'FWD', star: 2 },
            // 3星球员
            { name: '主力门将', pos: 'GK', star: 3 },
            { name: '铁卫后卫', pos: 'DEF', star: 3 },
            { name: '全能中场', pos: 'MID', star: 3 },
            { name: '效率前锋', pos: 'FWD', star: 3 },
            // 4星球员
            { name: '精英门将', pos: 'GK', star: 4 },
            { name: '领军后卫', pos: 'DEF', star: 4 },
            { name: '创意中场', pos: 'MID', star: 4 },
            { name: '锋线杀手', pos: 'FWD', star: 4 },
            // 5星球员
            { name: '传奇门将', pos: 'GK', star: 5 },
            { name: '传奇后卫', pos: 'DEF', star: 5 },
            { name: '传奇中场', pos: 'MID', star: 5 },
            { name: '传奇前锋', pos: 'FWD', star: 5 }
        ];
        return presets;
    },

    // ===== 球探招募 =====
    rollStar() {
        const roll = Math.random() * 100;
        let cumulative = 0;
        for (let star = 1; star <= 5; star++) {
            cumulative += ScoutConfig.rates[star];
            if (roll < cumulative) return star;
        }
        return 1;
    },

    getRandomPosition() {
        const positions = ['GK', 'DEF', 'MID', 'FWD'];
        return positions[Math.floor(Math.random() * positions.length)];
    },

    generatePlayerName(position, star) {
        const nameTemplates = {
            GK: ['门将', '守门员', '守护者', '铁闸', '之盾'],
            DEF: ['后卫', '防守', '铁卫', '卫士', '坚壁'],
            MID: ['中场', '组织者', '核心', '指挥', '枢纽'],
            FWD: ['前锋', '射手', '杀手', '利刃', '终结者']
        };
        const starPrefix = { 1: '新手', 2: '普通', 3: '主力', 4: '精英', 5: '传奇' };
        const templates = nameTemplates[position];
        const suffix = templates[Math.floor(Math.random() * templates.length)];
        return starPrefix[star] + suffix;
    },

    scoutPlayer(paymentType) {
        const cost = paymentType === 'funds' ? ScoutConfig.fundsCost : ScoutConfig.goldCost;
        const res = Storage.getResources();

        if (paymentType === 'funds') {
            if (res.funds < cost) return { success: false, message: '资金不足(需' + cost + ')' };
            if (!Storage.spendFunds(cost)) return { success: false, message: '资金不足' };
        } else {
            if (res.gold < cost) return { success: false, message: '金币不足(需' + cost + ')' };
            if (!Storage.spendGold(cost)) return { success: false, message: '金币不足' };
        }

        const star = this.rollStar();
        const position = this.getRandomPosition();
        const name = this.generatePlayerName(position, star);

        const player = this.createPlayer(name, position, star);
        if (!player) {
            // 退款
            if (paymentType === 'funds') Storage.addFunds(cost);
            else Storage.addGold(cost);
            return { success: false, message: '创建球员失败，已退款' };
        }

        const costLabel = paymentType === 'funds' ? cost + '资金' : cost + '金币';
        return {
            success: true,
            message: '球探发现了 ' + name + ' (' + star + '星 ' + PositionName[position] + ')！',
            player: player,
            cost: cost,
            costLabel: costLabel
        };
    },

    // 招募球员（花金币购买）- 保留旧接口兼容
    recruitPlayer(name, position, star) {
        const cost = StarConfig[star].cost;
        const res = Storage.getResources();
        if (res.gold < cost) return { success: false, message: '金币不足(需' + cost + ')' };

        if (!Storage.spendGold(cost)) return { success: false, message: '金币不足' };

        const player = this.createPlayer(name, position, star);
        return { success: true, message: '成功招募 ' + name + ' (' + star + '星)' + ' 花费' + cost + '金币', player: player };
    },

    // 出售球员（回收部分金币）
    sellPlayer(playerId) {
        const players = Storage.getPlayers();
        const player = players.find(p => p.id === playerId);
        if (!player) return { success: false, message: '球员不存在' };

        const baseValue = StarConfig[player.star].cost;
        const levelBonus = player.level * 100;
        const sellPrice = Math.floor((baseValue + levelBonus) * 0.5);

        // 从球队移除
        Storage.removePlayerFromTeam(playerId);
        // 从球员库移除
        Storage.removePlayer(playerId);
        // 加金币
        Storage.addGold(sellPrice);

        return { success: true, message: '出售 ' + player.name + ' 获得 ' + sellPrice + ' 金币' };
    }
};